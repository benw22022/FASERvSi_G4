#include "SCTModuleGeometry.hh"
#include "G4IntersectionSolid.hh"
#include <cmath>


SCTModuleGeometry::SCTModuleGeometry()
{   
    // Calculate bounding box dimensions
    G4double x_bounds = fStripLength * sin(fStereoAngle) + fPlaneWidth * cos(fStereoAngle);
    G4double y_bounds = fStripLength * cos(fStereoAngle) + fPlaneWidth * sin(fStereoAngle);
    G4double z_bounds = fModuleHeight;

    fModuleBoundingBox = new G4Box("module_bounding_box", x_bounds/2, y_bounds/2, z_bounds/2);  // Oriented with long edge in y-direction
    fModule_log = new G4LogicalVolume(fModuleBoundingBox, fAir, "module_log", 0,0,0);

    G4Box* fStrip_plane = new G4Box("strip_plane", fPlaneWidth/2, fStripLength/2, fPlaneThickness/2);  // Oriented with long edge in y-direction
    G4Box* fStrip_indiv = new G4Box("strip_indiv", fPlaneWidth/2, stripWidth()/2, fPlaneThickness/2);  // Oriented with long edge in y-direction
    fStrip_plane_log = new G4LogicalVolume(fStrip_plane, fSilicon, "strip_plane_log", 0,0,0);
    fStrip_indiv_log = new G4LogicalVolume(fStrip_indiv, fSilicon, "strip_inidv_log", 0,0,0);
    fStrip_div = new G4PVDivision("strip_div", fStrip_indiv_log, fStrip_plane_log, kXAxis, fNstrips, 0);
    
    // Define the stereo angle rotation matrix
    // In https://www.sciencedirect.com/science/article/pii/S016890020601388X
    // It is documented that the strips are counter-rotated by 20 mrad each side to give a 40 mrad stereo angle
    G4RotationMatrix* rot_side1 = new G4RotationMatrix();
    rot_side1->rotateZ(fStereoAngle/2);

    G4RotationMatrix* rot_side2 = new G4RotationMatrix();
    rot_side2->rotateZ(-fStereoAngle/2);

    // Create a tracking plane that we can set to be senstive to record truth hits
    // G4Box* fTruth_plane = new G4Box("strip_plane", fPlaneWidth/2, fStripLength/2, fPlaneSeparation/2);  // Oriented with long edge in y-direction
    G4Box* fTruthTrackerPlane = new G4Box("strip_plane", fPlaneWidth/2, fStripLength/2, fPlaneSeparation/2);  // Oriented with long edge in y-direction
    // G4IntersectionSolid* fTruthTrackerPlane = new G4IntersectionSolid("truth_tracker_plane", 
    //     fTruth_plane, 
    //     fTruth_plane, 
    //     rot, 
    //     G4ThreeVector(0,0,0)
    // );

    fTruthTrackerPlane_log = new G4LogicalVolume(fTruthTrackerPlane, fAir, "truth_tracker_plane_log", 0,0,0);
    G4VPhysicalVolume* truth_tracker_plane_phys = new G4PVPlacement(
        0, 
        G4ThreeVector(0, 0, 0), 
        fTruthTrackerPlane_log, 
        "truth_tracker_plane_phys", 
        fModule_log, 
        false, 
        0);
        
    // Place the two strip planes inside the module bounding box
    G4VPhysicalVolume* strip_plane_side1_phys = new G4PVPlacement(
        rot_side1, 
        G4ThreeVector(0, 0, -fPlaneThickness/2 - fPlaneSeparation/2), 
        fStrip_plane_log, 
        "SCT_front_phys", 
        fModule_log, 
        true, 
        0);

    // Apply stereo angle rotation around Z-axis for the back strip plane  
    G4VPhysicalVolume* strip_plane_side2_phys = new G4PVPlacement(
        rot_side2, 
        G4ThreeVector(0, 0, fPlaneThickness/2 + fPlaneSeparation/2), 
        fStrip_plane_log, 
        "SCT_back_phys", 
        fModule_log,
        false, 
        1);

    // Set visibility attributes for bounding box
    G4VisAttributes* boxVisAtt = new G4VisAttributes(G4Colour::Brown());
    boxVisAtt->SetForceWireframe(true);
    boxVisAtt->SetVisibility(false);
    fModule_log->SetVisAttributes(boxVisAtt);

    // Set visibility attributes for silicon planes
    G4VisAttributes* strip_planeVisAtt = new G4VisAttributes(G4Colour::Green());
    // strip_planeVisAtt->SetForceWireframe(true);
    strip_planeVisAtt->SetForceSolid(true);
    fStrip_plane_log->SetVisAttributes(strip_planeVisAtt);

    // Make individual strips invisible in visualization (too many to display usefully)
    G4VisAttributes* strip_invis = new G4VisAttributes(G4Colour::Green());
    strip_invis->SetVisibility(false);
    // strip_invis->SetForceWireframe(true);
    // strip_invis->SetVisibility(true);
    fStrip_indiv_log->SetVisAttributes(strip_invis);

    // Truth tracker vis
    G4VisAttributes* truthVisAtt = new G4VisAttributes(G4Colour::Brown());
    truthVisAtt->SetForceSolid(true);
    // truthVisAtt->SetVisibility(true);
    truthVisAtt->SetVisibility(false);
    fTruthTrackerPlane_log->SetVisAttributes(truthVisAtt);
}

G4VPhysicalVolume* SCTModuleGeometry::PlaceModule(G4LogicalVolume* mother_log, const G4ThreeVector& position, G4RotationMatrix* rotation, G4int copyNo) const
{
    G4VPhysicalVolume* module_phys = new G4PVPlacement(
        rotation,
        position,
        fModule_log,
        "SCT_module_phys",
        mother_log,
        false,
        copyNo);
    return module_phys;
}